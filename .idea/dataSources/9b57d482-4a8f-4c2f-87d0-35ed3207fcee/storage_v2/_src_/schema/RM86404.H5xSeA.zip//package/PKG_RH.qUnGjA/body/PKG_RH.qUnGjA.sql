create PACKAGE BODY PKG_RH IS
     --PROCEDURE INSERIR ALTERAR FUNC 
     PROCEDURE INSERT_UPDATE_FUNC(V_ID_FUNC IN FUNC.ID_FUNC%TYPE,
                                     V_NOME_FUNC IN FUNC.NOME_FUNC%TYPE,
                                     V_ID_DEPT IN FUNC.ID_DEPT%TYPE,
                                     V_CPF IN FUNC.CPF%TYPE,
                                     V_DATA_CONT IN FUNC.DATA_CONT%TYPE,
                                     V_DATA_DESLIG IN FUNC.DATA_DESLIG%TYPE,
                                     V_DATA_NASC IN FUNC.DATA_NASC%TYPE,
                                     V_ENDERECO IN FUNC.ENDERECO%TYPE,
                                     V_SALARIO IN FUNC.SALARIO%TYPE,
                                     V_STATUS IN FUNC.STATUS%TYPE)
            IS N_CPF INT;
            BEGIN
                BEGIN
                    SELECT 1
                    INTO N_CPF
                    FROM FUNC
                    WHERE ID_FUNC = V_ID_FUNC;
                EXCEPTION 
                    WHEN OTHERS THEN
                        N_CPF := 0;
                END;

                IF N_CPF = 0 THEN
                    INSERT INTO FUNC(ID_FUNC, NOME_FUNC, ID_DEPT, CPF, DATA_CONT, DATA_DESLIG, DATA_NASC, ENDERECO, SALARIO, STATUS)
                    VALUES(SEQ_FUNC_ID.NEXTVAL, V_NOME_FUNC, V_ID_DEPT, V_CPF, V_DATA_CONT, V_DATA_DESLIG, V_DATA_NASC, V_ENDERECO, V_SALARIO, V_STATUS);
                ELSE
                    UPDATE FUNC 
                    SET NOME_FUNC = V_NOME_FUNC, ID_DEPT = V_ID_DEPT, CPF = V_CPF, DATA_CONT = V_DATA_CONT,
                        DATA_DESLIG = V_DATA_DESLIG, DATA_NASC = V_DATA_NASC, ENDERECO = V_ENDERECO, SALARIO = V_SALARIO, STATUS = V_STATUS
                    WHERE ID_FUNC = V_ID_FUNC;
                END IF;
                COMMIT;
            END INSERT_UPDATE_FUNC;

        --PROCEDURE DELETAR FUNC
        PROCEDURE DELETE_FUNC(V_ID_FUNC IN FUNC.ID_FUNC%TYPE) 
        IS
            V_VALIDACAO NUMBER;
        BEGIN
            BEGIN
                SELECT
                    1
                INTO V_VALIDACAO
                FROM
                    func
                WHERE
                    id_func = v_id_func;

            EXCEPTION
                WHEN OTHERS THEN
                    V_VALIDACAO := 0;
            END;

            IF V_VALIDACAO = 1 THEN
                DELETE FROM FUNC WHERE ID_FUNC = V_ID_FUNC;         
            END IF;
            COMMIT;
        END DELETE_FUNC;

        --PROCEDURE INSERT UPDATE DEPT
        PROCEDURE INSERT_UPDATE_DEPT(V_ID_DEPT IN DEPT.ID_DEPT%TYPE,
                                 V_NOME_DEPT IN DEPT.NOME_DEPT%TYPE,
                                 V_LOC_DEPT IN DEPT.LOC_DEPT%TYPE,
                                 V_RESPONSAVEL IN DEPT.RESPONSAVEL%TYPE)
            IS AUX_DEPT INT;            
            BEGIN
                BEGIN 
                    SELECT 1
                    INTO AUX_DEPT
                    FROM DEPT
                    WHERE ID_DEPT = V_ID_DEPT;
                EXCEPTION
                    WHEN OTHERS THEN 
                        AUX_DEPT := 0;
                END;

                IF AUX_DEPT = 0 THEN 
                    INSERT INTO DEPT(ID_DEPT, NOME_DEPT, LOC_DEPT, RESPONSAVEL)
                    VALUES(SEQ_DEPT_ID.NEXTVAL, V_NOME_DEPT, V_LOC_DEPT, V_RESPONSAVEL);

                ELSE 
                    UPDATE DEPT
                    SET NOME_DEPT = V_NOME_DEPT, LOC_DEPT = V_LOC_DEPT, RESPONSAVEL = V_RESPONSAVEL
                    WHERE ID_DEPT = V_ID_DEPT;
                END IF;
                COMMIT;
            END INSERT_UPDATE_DEPT;

        --PROCEDURE DELETE DEPT
        PROCEDURE DELETE_DEPT(V_ID_DEPT IN DEPT.ID_DEPT%TYPE)    
        IS
            V_VALIDACAO NUMBER;
        BEGIN
            BEGIN
                SELECT
                    1
                INTO V_VALIDACAO
                FROM
                    DEPT
                WHERE
                    ID_DEPT = V_ID_DEPT;

            EXCEPTION
                WHEN OTHERS THEN
                    V_VALIDACAO := 0;
            END;

            IF V_VALIDACAO = 1 THEN
                DELETE FROM FUNC WHERE ID_DEPT = V_ID_DEPT;         
            END IF;
            COMMIT;
        END DELETE_DEPT;       

        --PROCEDURE INSERT UPDATE BENEFICIOS
        PROCEDURE INSERT_UPDATE_BENEFICIOS(V_ID_BENEFICIO IN TB_BENEFICIO.ID_BENEFICIO%TYPE,
                                           V_NOME_BENEFICIO IN TB_BENEFICIO.NOME_BENEFICIO%TYPE,
                                           V_DESCRICAO_BENEFICIO IN TB_BENEFICIO.DESCRICAO_BENEFICIO%TYPE,
                                           V_PONTUACAO_BENEFICIO IN TB_BENEFICIO.PONTUACAO_BENEFICIO%TYPE)
        IS AUX_BENEFICIOS NUMBER(2);            
            BEGIN
                BEGIN 
                    SELECT 1
                    INTO AUX_BENEFICIOS
                    FROM TB_BENEFICIO
                    WHERE ID_BENEFICIO = V_ID_BENEFICIO;
                EXCEPTION
                    WHEN OTHERS THEN 
                        AUX_BENEFICIOS := 0;
                END;

                IF AUX_BENEFICIOS = 0 THEN 
                    INSERT INTO TB_BENEFICIO(ID_BENEFICIO, NOME_BENEFICIO, DESCRICAO_BENEFICIO, PONTUACAO_BENEFICIO)
                    VALUES(SEQ_BENEFICIO_ID.NEXTVAL, V_NOME_BENEFICIO, V_DESCRICAO_BENEFICIO, V_PONTUACAO_BENEFICIO);

                ELSE 
                    UPDATE TB_BENEFICIO
                    SET ID_BENEFICIO = V_ID_BENEFICIO, NOME_BENEFICIO = V_NOME_BENEFICIO, 
                        DESCRICAO_BENEFICIO = V_DESCRICAO_BENEFICIO, PONTUACAO_BENEFICIO = V_PONTUACAO_BENEFICIO
                    WHERE ID_BENEFICIO = V_ID_BENEFICIO;
                END IF;
                COMMIT;
            END INSERT_UPDATE_BENEFICIOS;

            --PROCEDURE DELETE BENEFICIO
            PROCEDURE DELETE_BENEFICIO(V_ID_BENEFICIO IN TB_BENEFICIO.ID_BENEFICIO%TYPE)    
                IS
                    V_VALIDACAO NUMBER;
                BEGIN
                    BEGIN
                        SELECT
                            1
                        INTO V_VALIDACAO
                        FROM
                            TB_BENEFICIO
                        WHERE
                            ID_BENEFICIO = V_ID_BENEFICIO;

                    EXCEPTION
                        WHEN OTHERS THEN
                            V_VALIDACAO := 0;
                    END;

                    IF V_VALIDACAO = 1 THEN
                        DELETE FROM TB_BENEFICIOS_FUNCIONARIO WHERE FK_BENEFICIO = V_ID_BENEFICIO;
                        DELETE FROM TB_BENEFICIO WHERE ID_BENEFICIO = V_ID_BENEFICIO;         
                    END IF;
                    COMMIT;
            END DELETE_BENEFICIO; 

          --PROCEDURE INSERT BENEFICIO FUNCIONARIO
          PROCEDURE INSERT_BENEFICIO_FUNCIONARIO(V_ID_BENEFICO IN TB_BENEFICIOS_FUNCIONARIO.FK_FUNCIONARIO%TYPE,
                                                V_ID_FUNCIONARIO IN TB_BENEFICIOS_FUNCIONARIO.FK_BENEFICIO%TYPE)  
            IS  
                CURSOR CBUSCABENEFICIO IS  
                SELECT FK_BENEFICIO 
                FROM TB_BENEFICIOS_FUNCIONARIO
                WHERE FK_FUNCIONARIO = V_ID_FUNCIONARIO;

                V_PONTUACAO_BENEFICIO NUMBER(3);
                V_TOTAL_BENEFICIO NUMBER(5);

            BEGIN 

                FOR RBUSCABENEFICIO IN CBUSCABENEFICIO LOOP
                    SELECT PONTUACAO_BENEFICIO 
                    INTO V_PONTUACAO_BENEFICIO
                    FROM TB_BENEFICIO
                    WHERE ID_BENEFICIO = RBUSCABENEFICIO.FK_BENEFICIO;
                    --DUVIDA ATRIBUICAO += 
                    V_TOTAL_BENEFICIO := V_PONTUACAO_BENEFICIO;
                END LOOP;

                IF V_TOTAL_BENEFICIO < 1000 THEN 
                    INSERT INTO TB_BENEFICIOS_FUNCIONARIO(ID_BENEFICIOS_FUNCIONARIO, FK_FUNCIONARIO, FK_BENEFICIO)
                            VALUES(SEQ_BENEFICIOS_FUNCIONARIO_ID.NEXTVAL,V_ID_FUNCIONARIO , V_ID_BENEFICO);
                END IF;
                COMMIT;              
            END INSERT_BENEFICIO_FUNCIONARIO;

         --FUNCAO TEMPO DE CASA DE UM FUNCIONARIO
         FUNCTION TEMPO_FUNC(V_ID_FUNC IN NUMBER) RETURN NUMBER
         IS TEMPO_CASA DATE;
            BEGIN 
                SELECT FUNC.DATA_CONT AS TEMPO_CASA
                INTO TEMPO_CASA
                FROM FUNC WHERE ID_FUNC = V_ID_FUNC;

             RETURN (TEMPO_CASA - SYSDATE);
            EXCEPTION 
                WHEN OTHERS THEN
                    RETURN (NULL);
         END;

         --FUNCAO MEDIA SALARIO DEPARTAMENTO
         FUNCTION MEDIA_SALARIO_DEPT(V_ID_DEPT IN NUMBER) RETURN NUMBER
         IS MEDIA_SALARIO NUMBER;
            BEGIN 
                SELECT MEDIAN(FUNC.SALARIO) AS MEDIA_SALARIO 
                INTO MEDIA_SALARIO
                FROM FUNC WHERE ID_DEPT = V_ID_DEPT;
                RETURN (MEDIA_SALARIO);
                EXCEPTION 
                    WHEN OTHERS THEN
                        RETURN (NULL);
         END;

         --FUNCAO MAIOR SALARIO DEPARTAMENTO
          FUNCTION MAIOR_SALARIO_DEPT(V_ID_DEPT IN NUMBER) RETURN NUMBER
          IS MAIOR_SALARIO NUMBER;
            BEGIN
                SELECT MAX(FUNC.SALARIO) AS MAIOR_SALARIO 
                INTO MAIOR_SALARIO
                FROM FUNC WHERE ID_DEPT = V_ID_DEPT;
                RETURN (MAIOR_SALARIO);
                EXCEPTION
                    WHEN OTHERS THEN
                        RETURN (NULL);
         END;

         --FUNCAO MENOR SALARIO DEPARTAMENTO
         FUNCTION MENOR_SALARIO_DEPT(V_ID_DEPT IN NUMBER) RETURN NUMBER
          IS MENOR_SALARIO NUMBER;
            BEGIN
                SELECT MIN(FUNC.SALARIO) AS MENOR_SALARIO 
                INTO MENOR_SALARIO
                FROM FUNC WHERE ID_DEPT = V_ID_DEPT;
                RETURN (MENOR_SALARIO);
                EXCEPTION
                    WHEN OTHERS THEN
                        RETURN (NULL);
         END MENOR_SALARIO_DEPT;

         --FUNCAO VALOR TOTAL BENEFICIO FUNCIONARIO
        FUNCTION VALOR_TOTAL_BENEFICIO_FUNCIONARIO(V_ID_FUNC IN NUMBER) RETURN NUMBER
         IS  
                CURSOR CBUSCABENEFICIO IS  
                SELECT FK_BENEFICIO 
                FROM TB_BENEFICIOS_FUNCIONARIO
                WHERE FK_FUNCIONARIO = V_ID_FUNC;

                V_PONTUACAO_BENEFICIO NUMBER(3);
                V_TOTAL_BENEFICIO NUMBER(5);

            BEGIN 
                V_PONTUACAO_BENEFICIO := 0;

                FOR RBUSCABENEFICIO IN CBUSCABENEFICIO LOOP
                    SELECT PONTUACAO_BENEFICIO 
                    INTO V_PONTUACAO_BENEFICIO
                    FROM TB_BENEFICIO
                    WHERE ID_BENEFICIO = RBUSCABENEFICIO.FK_BENEFICIO;
                    --DUVIDA ATRIBUICAO += 
                    V_TOTAL_BENEFICIO := V_PONTUACAO_BENEFICIO;
                END LOOP;

                IF V_TOTAL_BENEFICIO > 0 THEN 
                    RETURN(V_TOTAL_BENEFICIO);
                ELSE
                    RETURN(NULL);
                END IF;      
            END VALOR_TOTAL_BENEFICIO_FUNCIONARIO;
END PKG_RH;
/

