create procedure atual_status (v_func_status in func.status%type)
is 
    cursor cBuscaStatus is  
    select salario, data_deslig, status 
    from func;

n_soma number;
d_deslig DATE;

begin 
    n_soma := 100;
    d_deslig := SYSDATE;

    if v_func_status = 'S' THEN
        for r_BuscaStatus in cBuscaStatus loop
            UPDATE FUNC SET salario = r_BuscaStatus.salario + 100 where r_BuscaStatus.status = 'S';
            Commit;
        end loop;
    else 
        for r_BuscaStatus in cBuscaStatus loop
            UPDATE FUNC SET data_deslig = d_deslig  where r_BuscaStatus.data_deslig = null;
            Commit;
        end loop;
    end if;
end;
/

