create PROCEDURE consulta_emp
(p_id IN empregadon.cd_empregado%TYPE,
p_name OUT empregadon.nm_empregado%TYPE,
p_salario OUT empregadon.vl_salario%TYPE) IS
BEGIN
SELECT nm_empregado, vl_salario INTO p_name, p_salario
FROM empregadon
WHERE cd_empregado = p_id;
END consulta_emp;
/

