create PROCEDURE DELETE_BENEFICIO(V_ID_BENEFICIO IN TB_BENEFICIO.ID_BENEFICIO%TYPE)    
                IS
                    V_VALIDACAO NUMBER;
                BEGIN
                    BEGIN
                        SELECT
                            1
                        INTO V_VALIDACAO
                        FROM
                            TB_BENEFICIO
                        WHERE
                            ID_BENEFICIO = V_ID_BENEFICIO;

                    EXCEPTION
                        WHEN OTHERS THEN
                            V_VALIDACAO := 0;
                    END;

                    IF V_VALIDACAO = 1 THEN
                        DELETE FROM TB_BENEFICIOS_FUNCIONARIO WHERE FK_BENEFICIO = V_ID_BENEFICIO;
                        DELETE FROM TB_BENEFICIO WHERE ID_BENEFICIO = V_ID_BENEFICIO;         
                    END IF;
                    COMMIT;
            END DELETE_BENEFICIO;
/

