create PROCEDURE DELETE_DEPT(V_ID_DEPT IN DEPT.ID_DEPT%TYPE)    
        IS
            V_VALIDACAO NUMBER;
        BEGIN
            BEGIN
                SELECT
                    1
                INTO V_VALIDACAO
                FROM
                    DEPT
                WHERE
                    ID_DEPT = V_ID_DEPT;

            EXCEPTION
                WHEN OTHERS THEN
                    V_VALIDACAO := 0;
            END;

            IF V_VALIDACAO = 1 THEN
                DELETE FROM FUNC WHERE ID_DEPT = V_ID_DEPT;         
            END IF;
            COMMIT;
        END DELETE_DEPT;
/

