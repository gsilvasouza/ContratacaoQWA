create PROCEDURE DELETE_FUNC( V_ID_FUNC IN FUNC.ID_FUNC%TYPE ) 
        IS
            V_VALIDACAO NUMBER;
        BEGIN
            BEGIN
                SELECT
                    1
                INTO V_VALIDACAO
                FROM
                    func
                WHERE
                    id_func = v_id_func;

            EXCEPTION
                WHEN OTHERS THEN
                    V_VALIDACAO := 0;
            END;

            IF V_VALIDACAO = 1 THEN
                DELETE FROM FUNC WHERE ID_FUNC = V_ID_FUNC;         
            END IF;
            COMMIT;
        END DELETE_FUNC;
/

