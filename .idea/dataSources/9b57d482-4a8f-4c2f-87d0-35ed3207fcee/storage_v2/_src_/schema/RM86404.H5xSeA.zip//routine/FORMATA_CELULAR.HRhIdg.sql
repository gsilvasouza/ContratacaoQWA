create PROCEDURE formata_celular
(celular IN OUT VARCHAR2) IS
BEGIN
celular := '(' || SUBSTR(celular,1,2) ||
')' || SUBSTR(celular,3,5) ||
'-' || SUBSTR(celular,8);
END formata_celular;
/

