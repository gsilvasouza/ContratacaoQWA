create PROCEDURE INSERIR_ALTERAR_DEPARTAMENTO (V_ID_DEPT IN DEPT.ID_DEPT%TYPE,
                                                V_NOME_DEPT IN DEPT.NOME_DEPT%TYPE,
                                                V_LOC_DEPT IN DEPT.LOC_DEPT%TYPE,
                                                V_REPONSAVEL IN DEPT.RESPONSAVEL%TYPE)
            IS AUX_DEPT INT;            
            BEGIN
                BEGIN 
                    SELECT 1
                    INTO AUX_DEPT
                    FROM DEPT
                    WHERE ID_DEPT = V_ID_DEPT;
                EXCEPTION
                    WHEN OTHERS THEN 
                        AUX_DEPT := 0;
                END;

                IF AUX_DEPT = 0 THEN 
                    INSERT INTO DEPT(ID_DEPT, NOME_DEPT, LOC_DEPT, RESPONSAVEL)
                    VALUES(SEQ_DEPT_ID.NEXTVAL, V_NOME_DEPT, V_LOC_DEPT, V_REPONSAVEL);

                ELSE 
                    UPDATE DEPT
                    SET NOME_DEPT = V_NOME_DEPT, LOC_DEPT = V_LOC_DEPT, RESPONSAVEL = V_REPONSAVEL
                    WHERE ID_DEPT = V_ID_DEPT;
                END IF;
                COMMIT;
            END INSERIR_ALTERAR_DEPARTAMENTO;
/

