create PROCEDURE INSERIR_ALTERAR_FUNC(V_ID_FUNC IN FUNC.ID_FUNC%TYPE,
                                     V_NOME_FUNC IN FUNC.NOME_FUNC%TYPE,
                                     V_ID_DEPT IN FUNC.ID_DEPT%TYPE,
                                     V_CPF IN FUNC.CPF%TYPE,
                                     V_DATA_CONT IN FUNC.DATA_CONT%TYPE,
                                     V_DATA_DESLIG IN FUNC.DATA_DESLIG%TYPE,
                                     V_DATA_NASC IN FUNC.DATA_NASC%TYPE,
                                     V_ENDERECO IN FUNC.ENDERECO%TYPE,
                                     V_SALARIO IN FUNC.SALARIO%TYPE,
                                     V_STATUS IN FUNC.STATUS%TYPE)
            IS N_CPF INT;
            BEGIN
                BEGIN
                    SELECT 1
                    INTO N_CPF
                    FROM FUNC
                    WHERE ID_FUNC = V_ID_FUNC;
                EXCEPTION 
                    WHEN OTHERS THEN
                        N_CPF := 0;
                END;

                IF N_CPF = 0 THEN
                    INSERT INTO FUNC(ID_FUNC, NOME_FUNC, ID_DEPT, CPF, DATA_CONT, DATA_DESLIG, DATA_NASC, ENDERECO, SALARIO, STATUS)
                    VALUES(SEQ_FUNC_ID.NEXTVAL, V_NOME_FUNC, V_ID_DEPT, V_CPF, V_DATA_CONT, V_DATA_DESLIG, V_DATA_NASC, V_ENDERECO, V_SALARIO, V_STATUS);
                ELSE
                    UPDATE FUNC 
                    SET NOME_FUNC = V_NOME_FUNC, ID_DEPT = V_ID_DEPT, CPF = V_CPF, DATA_CONT = V_DATA_CONT,
                        DATA_DESLIG = V_DATA_DESLIG, DATA_NASC = V_DATA_NASC, ENDERECO = V_ENDERECO, SALARIO = V_SALARIO, STATUS = V_STATUS
                    WHERE ID_FUNC = V_ID_FUNC;
                END IF;
                COMMIT;
            END INSERIR_ALTERAR_FUNC;
/

