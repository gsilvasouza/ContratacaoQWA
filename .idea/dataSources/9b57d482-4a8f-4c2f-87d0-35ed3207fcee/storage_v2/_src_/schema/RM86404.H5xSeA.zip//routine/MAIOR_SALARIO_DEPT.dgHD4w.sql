create FUNCTION MAIOR_SALARIO_DEPT(V_ID_DEPT IN NUMBER) RETURN NUMBER
          IS MAIOR_SALARIO NUMBER;
            BEGIN
                SELECT MAX(FUNC.SALARIO) AS MAIOR_SALARIO 
                into MAIOR_SALARIO
                FROM FUNC WHERE ID_DEPT = V_ID_DEPT;
                RETURN (MAIOR_SALARIO);
                EXCEPTION
                    WHEN OTHERS THEN
                        RETURN (NULL);
         END;
/

