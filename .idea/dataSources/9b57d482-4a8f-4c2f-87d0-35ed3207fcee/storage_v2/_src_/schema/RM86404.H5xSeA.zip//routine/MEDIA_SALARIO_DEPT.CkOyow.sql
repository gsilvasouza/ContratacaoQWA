create FUNCTION MEDIA_SALARIO_DEPT(V_ID_DEPT IN NUMBER) RETURN NUMBER
         IS MEDIA_SALARIO NUMBER;
            BEGIN 
                SELECT MEDIAN(FUNC.SALARIO) AS MEDIA_SALARIO 
                INTO MEDIA_SALARIO
                FROM FUNC WHERE ID_DEPT = V_ID_DEPT;
                RETURN (MEDIA_SALARIO);
                EXCEPTION 
                    WHEN OTHERS THEN
                        RETURN (NULL);
         END;
/

