create FUNCTION MENOR_SALARIO_DEPT(V_ID_DEPT IN NUMBER) RETURN NUMBER
          IS MENOR_SALARIO NUMBER;
            BEGIN
                SELECT MIN(FUNC.SALARIO) AS MENOR_SALARIO 
                INTO MENOR_SALARIO
                FROM FUNC WHERE ID_DEPT = V_ID_DEPT;
                RETURN (MENOR_SALARIO);
                EXCEPTION
                    WHEN OTHERS THEN
                        RETURN (NULL);
         END MENOR_SALARIO_DEPT;
/

