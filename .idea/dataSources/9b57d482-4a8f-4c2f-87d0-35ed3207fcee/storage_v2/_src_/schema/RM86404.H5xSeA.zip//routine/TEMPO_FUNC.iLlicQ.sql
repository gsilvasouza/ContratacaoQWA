create FUNCTION TEMPO_FUNC(V_ID_FUNC IN NUMBER) RETURN NUMBER
         IS TEMPO_CASA DATE;
            BEGIN 
                SELECT FUNC.DATA_CONT AS TEMPO_CASA
                INTO TEMPO_CASA
                FROM FUNC WHERE ID_FUNC = V_ID_FUNC;

             RETURN (TEMPO_CASA - SYSDATE);
            EXCEPTION 
                WHEN OTHERS THEN
                    RETURN (NULL);
         END;
/

