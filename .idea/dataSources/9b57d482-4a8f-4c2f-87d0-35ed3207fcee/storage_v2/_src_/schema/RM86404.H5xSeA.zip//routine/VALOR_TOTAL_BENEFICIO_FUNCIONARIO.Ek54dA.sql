create FUNCTION VALOR_TOTAL_BENEFICIO_FUNCIONARIO(V_ID_FUNC IN NUMBER) RETURN NUMBER
         IS  
                CURSOR CBUSCABENEFICIO IS  
                SELECT FK_BENEFICIO 
                FROM TB_BENEFICIOS_FUNCIONARIO
                WHERE FK_FUNCIONARIO = V_ID_FUNC;

                V_PONTUACAO_BENEFICIO NUMBER(3);
                V_TOTAL_BENEFICIO NUMBER(5);

            BEGIN 
                V_PONTUACAO_BENEFICIO := 0;

                FOR RBUSCABENEFICIO IN CBUSCABENEFICIO LOOP
                    SELECT PONTUACAO_BENEFICIO 
                    INTO V_PONTUACAO_BENEFICIO
                    FROM TB_BENEFICIO
                    WHERE ID_BENEFICIO = RBUSCABENEFICIO.FK_BENEFICIO;
                    --DUVIDA ATRIBUICAO += 
                    V_TOTAL_BENEFICIO := V_PONTUACAO_BENEFICIO;
                END LOOP;

                IF V_TOTAL_BENEFICIO > 0 THEN 
                    RETURN(V_TOTAL_BENEFICIO);
                ELSE
                    RETURN(NULL);
                END IF;      
            END VALOR_TOTAL_BENEFICIO_FUNCIONARIO;
/

