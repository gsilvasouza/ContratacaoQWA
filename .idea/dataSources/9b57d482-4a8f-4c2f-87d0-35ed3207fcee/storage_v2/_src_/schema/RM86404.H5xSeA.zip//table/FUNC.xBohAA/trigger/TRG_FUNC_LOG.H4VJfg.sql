create trigger TRG_FUNC_LOG
    after insert or update or delete
    on FUNC
    for each row
BEGIN
    IF INSERTING THEN
        INSERT INTO FUNC_LOG
            (ID_LOG_FUNC,
            ID_FUNC,
            CPF,
            NOME_FUNC,
            DATA_CONT, 
            DATA_DESLIG, 
            DATA_NASC, 
            ENDERECO,  
            SALARIO,
            STATUS,
            ID_DEPT,
            TIPO_ALTERACAO,
            DATA_OPERACAO)
        VALUES (
            SEQ_FUNC_LOG_ID.NEXTVAL,
            :NEW.ID_FUNC,
            :NEW.CPF,
            :NEW.NOME_FUNC,
            :NEW.DATA_CONT, 
            :NEW.DATA_DESLIG, 
            :NEW.DATA_NASC, 
            :NEW.ENDERECO, 
            :NEW.SALARIO,
            :NEW.STATUS,
            :NEW.ID_DEPT,
            'INSERT',
            SYSDATE);
    ELSIF UPDATING THEN
    INSERT INTO FUNC_LOG
            (ID_LOG_FUNC,
            ID_FUNC,
            CPF,
            NOME_FUNC,
            DATA_CONT, 
            DATA_DESLIG, 
            DATA_NASC, 
            ENDERECO, 
            SALARIO,
            STATUS,
            ID_DEPT,
            TIPO_ALTERACAO,
            DATA_OPERACAO)
        VALUES (SEQ_FUNC_LOG_ID.NEXTVAL,
            :NEW.ID_FUNC,
            :NEW.CPF,
            :NEW.NOME_FUNC,
            :NEW.DATA_CONT, 
            :NEW.DATA_DESLIG, 
            :NEW.DATA_NASC, 
            :NEW.ENDERECO,
            :NEW.SALARIO,
            :NEW.STATUS,
            :NEW.ID_DEPT,
            'UPDATE',
            SYSDATE);

    ELSE      
     INSERT INTO FUNC_LOG
            (ID_LOG_FUNC,
            ID_FUNC,
            CPF,
            NOME_FUNC,
            DATA_CONT, 
            DATA_DESLIG, 
            DATA_NASC, 
            ENDERECO,
            SALARIO,
            STATUS,
            ID_DEPT,
            TIPO_ALTERACAO,
            DATA_OPERACAO)
        VALUES (SEQ_FUNC_LOG_ID.NEXTVAL,
            :OLD.ID_FUNC,
            :OLD.CPF,
            :OLD.NOME_FUNC,
            :OLD.DATA_CONT, 
            :OLD.DATA_DESLIG, 
            :OLD.DATA_NASC, 
            :OLD.ENDERECO,
            :OLD.SALARIO,
            :OLD.STATUS,
            :OLD.ID_DEPT,
            'DELETE',
            SYSDATE);

    END IF;
END TRG_FUNC_LOG;
/

