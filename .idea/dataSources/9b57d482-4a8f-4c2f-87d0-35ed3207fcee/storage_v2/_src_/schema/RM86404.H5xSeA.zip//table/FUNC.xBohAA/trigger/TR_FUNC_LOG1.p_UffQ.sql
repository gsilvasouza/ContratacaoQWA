create trigger TR_FUNC_LOG1
    after insert or update or delete
    on FUNC
    for each row
begin
 if inserting then
    insert into log_func
    (
    id_log_func,
    id_func,
    nome_func,
    id_dept,
    cpf,
    data_cont,
    data_deslig,
    data_nasc,
    endereco,
    status,
    salario,
    tipo_alteracao,
    data_operacao)
    values
    (
    seq_log_func.nextval,
    :new.id_func,
    :new.nome_func,
    :new.id_dept,
    :new.cpf,
    :new.data_cont,
    :new.data_deslig,
    :new.data_nasc,
    :new.endereco,
    :new.status,
    :new.salario,
    'Inclusao',
    sysdate);
    elsif updating then
    insert into func_log
    (
    id_log_func,
    id_func,
    nome_func,
    id_dept,
    cpf,
    data_cont,
    data_deslig,
    data_nasc,
    endereco,
    status,
    salario,
    tipo_alteracao,
    data_operacao)
    values
    (
    seq_log_func.nextval,
    :new.id_func,
    :new.nome_func,
    :new.id_dept,
    :new.cpf,
    :new.data_cont,
    :new.data_deslig,
    :new.data_nasc,
    :new.endereco,
    :new.status,
    :new.salario,
    'Alteracao',
    sysdate);
    else
    insert into func_log
    (
    id_log_func,
    id_func,
    nome_func,
    id_dept,
    cpf,
    data_cont,
    data_deslig,
    data_nasc,
    endereco,
    status,
    salario,
    tipo_alteracao,
    data_operacao)
    values
    (
    seq_log_func.nextval,
    :new.id_func,
    :new.nome_func,
    :new.id_dept,
    :new.cpf,
    :new.data_cont,
    :new.data_deslig,
    :new.data_nasc,
    :new.endereco,
    :new.status,
    :new.salario,
    'Exclusao',
    sysdate);
    end if;
end tr_func_log1;
/

